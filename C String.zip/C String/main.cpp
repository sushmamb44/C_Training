#include <iostream>
#include "CString.h"
#include "Smart.h"
using namespace std;

int main()
{
	{


	

		CString s2("mohith");
		CString sss(s2);
		/*s2.show_string();*/

		CString s3("shivu"); 
		s3.show_string();

		SmartPointer sptr;
		sptr->accept_string();
		(*sptr).show_string();

		//s1 = s2;
		/*CString s4 = s2 + s3;
		s4.show_string();*/


		/*CString s2('W',10);
		s2.show_string();

		CString ss(s2);
		ss.show_string();*/
		
	}
		
	
	

	cout <<"Leak " << _CrtDumpMemoryLeaks() << endl;
	return 0;
}